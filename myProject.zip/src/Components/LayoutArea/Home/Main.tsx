import SignForm from "../AuthArea/SignForm/SignForm";

function Main(): JSX.Element {
    return (
        <div className="Main">
            <SignForm />
        </div>
    );
}

export default Main;
