import "./Footer.css";

function Footer(): JSX.Element {
    return (
        <div className="Footer">
			&#169; Eitan Etzion. May 2021
        </div>
    );
}

export default Footer;
