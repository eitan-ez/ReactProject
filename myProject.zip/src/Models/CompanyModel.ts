
class CompanyModel {
    id: number;
    name: string;
    email: string;
    password: string;
}

export default CompanyModel